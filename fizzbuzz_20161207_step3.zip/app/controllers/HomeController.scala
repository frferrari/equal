package controllers

import javax.inject._
import play.api.mvc._
import play.api.libs.json._
import scala.concurrent.ExecutionContext.Implicits.global

import services.FizzBuzzService

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject() extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def fizzbuzz(start: Int, end: Int) = Action.async { request =>
    val (s, e) = if ( start < end ) (start, end) else (end, start)

    for {
      r <- FizzBuzzService.rangeToSentence(s, e)
      o <- FizzBuzzService.countOccurrences(r)
    } yield {
      println(r)
      println(o)
      Ok(Json.obj("result" -> r, "report" -> o))
    }
  }

}
