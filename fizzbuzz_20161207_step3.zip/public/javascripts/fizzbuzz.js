$('#go-btn').click(function() {
    var startRange= $('#start-range').val();
    var endRange = $('#end-range').val();

    $.get("/fizzbuzz", { start: parseInt(startRange), end: parseInt(endRange) })
        .done(function(data) {
            $("#result-box").html(data.result);
            $("#report-box").html(data.report);
        });
});
