import org.scalatestplus.play._
import play.api.test._
import play.api.test.Helpers._
import services.FizzBuzzService

class ApplicationSpec extends PlaySpec with OneAppPerTest {

  "FizzBuzzService" should {

    //
    // No rule
    //
    "return '1' given [1,1]" in {
      await(FizzBuzzService.rangeToSentence(1, 1)) mustEqual("1")
    }

    "return '-1' given [-1,-1]" in {
      await(FizzBuzzService.rangeToSentence(-1, -1)) mustEqual("-1")
    }

    "return '1 2' given [1,2]" in {
      await(FizzBuzzService.rangeToSentence(1, 2)) mustEqual("1 2")
    }

    //
    // Contains a 3 rule
    //
    "return 'lucky' given [30,30]" in {
      await(FizzBuzzService.rangeToSentence(30,30)) mustEqual("lucky")
    }

    "return 'lucky' given [131,131]" in {
      await(FizzBuzzService.rangeToSentence(131,131)) mustEqual("lucky")
    }

    "return 'lucky' given [193,193]" in {
      await(FizzBuzzService.rangeToSentence(193,193)) mustEqual("lucky")
    }

    "return 'lucky' given [333,333]" in {
      await(FizzBuzzService.rangeToSentence(333, 333)) mustEqual("lucky")
    }

    "return 'lucky lucky' given [333,334]" in {
      await(FizzBuzzService.rangeToSentence(333, 334)) mustEqual("lucky lucky")
    }

    //
    // Multiple of 3 rule (fizz)
    //
    "return 'lucky' given [3,3]" in {
      await(FizzBuzzService.rangeToSentence(3, 3)) mustEqual("lucky")
    }

    "return '1 2 lucky' given 1,3" in {
      await(FizzBuzzService.rangeToSentence(1, 3)) mustEqual("1 2 lucky")
    }

    "return 'lucky 4' given [3,4]" in {
      await(FizzBuzzService.rangeToSentence(3, 4)) mustEqual("lucky 4")
    }

    //
    // Multiple of 5 rule (buzz)
    //
    "return 'buzz' given [5,5]" in {
      await(FizzBuzzService.rangeToSentence(5, 5)) mustEqual("buzz")
    }

    //
    // Multiple of 15 rule (fizzbuzz)
    //
    "return 'fizzbuzz' given [0,0]" in {
      await(FizzBuzzService.rangeToSentence(0,0)) mustEqual("fizzbuzz")
    }

    "return 'buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz' given [5,15]" in {
      await(FizzBuzzService.rangeToSentence(5,15)) mustEqual("buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz")
    }

    "return 'buzz -4 lucky -2 -1 fizzbuzz 1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz' given [-5,15]" in {
      await(FizzBuzzService.rangeToSentence(-5,15)) mustEqual("buzz -4 lucky -2 -1 fizzbuzz 1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz")
    }

    "return '1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz' given [1, 20]" in {
      await(FizzBuzzService.rangeToSentence(1,20)) mustEqual("1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz")
    }

    "return 'lucky -29 -28 fizz -26 buzz fizz lucky -22 fizz buzz -19 fizz -17 -16 fizzbuzz -14 lucky fizz -11 buzz fizz -8 -7 fizz buzz -4 lucky -2 -1 fizzbuzz 1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz fizz 22 lucky fizz buzz 26 fizz 28 29 lucky' given [-30, 30]" in {
      await(FizzBuzzService.rangeToSentence(-30,30)) mustEqual("lucky -29 -28 fizz -26 buzz fizz lucky -22 fizz buzz -19 fizz -17 -16 fizzbuzz -14 lucky fizz -11 buzz fizz -8 -7 fizz buzz -4 lucky -2 -1 fizzbuzz 1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz fizz 22 lucky fizz buzz 26 fizz 28 29 lucky")
    }

  }

}
