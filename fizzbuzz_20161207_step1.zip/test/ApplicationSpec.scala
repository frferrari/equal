import org.scalatestplus.play._
import play.api.test._
import play.api.test.Helpers._
import services.FizzBuzzService

class ApplicationSpec extends PlaySpec with OneAppPerTest {

  "FizzBuzzService" should {

    //
    // No rule
    //
    "return '1' given [1,1]" in {
      await(FizzBuzzService.rangeToSentence(1, 1)) mustEqual("1")
    }

    "return '-1' given [-1,-1]" in {
      await(FizzBuzzService.rangeToSentence(-1, -1)) mustEqual("-1")
    }

    "return '1 2' given [1,2]" in {
      await(FizzBuzzService.rangeToSentence(1, 2)) mustEqual("1 2")
    }

    //
    // Multiple of 3 rule (fizz)
    //
    "return 'fizz' given [3,3]" in {
      await(FizzBuzzService.rangeToSentence(3, 3)) mustEqual("fizz")
    }

    "return '1 2 fizz' given 1,3" in {
      await(FizzBuzzService.rangeToSentence(1, 3)) mustEqual("1 2 fizz")
    }

    "return 'fizz 4' given [3,4]" in {
      await(FizzBuzzService.rangeToSentence(3, 4)) mustEqual("fizz 4")
    }

    //
    // Multiple of 5 rule (buzz)
    //
    "return 'buzz' given [5,5]" in {
      await(FizzBuzzService.rangeToSentence(5, 5)) mustEqual("buzz")
    }

    //
    // Multiple of 15 rule (fizzbuzz)
    //
    "return 'fizzbuzz' given [0,0]" in {
      await(FizzBuzzService.rangeToSentence(0,0)) mustEqual("fizzbuzz")
    }

    "return 'buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz' given [5,15]" in {
      await(FizzBuzzService.rangeToSentence(5,15)) mustEqual("buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz")
    }

    "return 'buzz -4 fizz -2 -1 fizzbuzz 1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz' given [-5,15]" in {
      await(FizzBuzzService.rangeToSentence(-5,15)) mustEqual("buzz -4 fizz -2 -1 fizzbuzz 1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz")
    }

    "return '1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz' given [1, 20]" in {
      await(FizzBuzzService.rangeToSentence(1,20)) mustEqual("1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz")
    }

    "return 'fizzbuzz -29 -28 fizz -26 buzz fizz -23 -22 fizz buzz -19 fizz -17 -16 fizzbuzz -14 -13 fizz -11 buzz fizz -8 -7 fizz buzz -4 fizz -2 -1 fizzbuzz 1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz fizz 22 23 fizz buzz 26 fizz 28 29 fizzbuzz' given [-30, 30]" in {
      await(FizzBuzzService.rangeToSentence(-30,30)) mustEqual("fizzbuzz -29 -28 fizz -26 buzz fizz -23 -22 fizz buzz -19 fizz -17 -16 fizzbuzz -14 -13 fizz -11 buzz fizz -8 -7 fizz buzz -4 fizz -2 -1 fizzbuzz 1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz fizz 22 23 fizz buzz 26 fizz 28 29 fizzbuzz")
    }

  }

}
