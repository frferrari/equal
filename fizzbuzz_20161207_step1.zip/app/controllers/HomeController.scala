package controllers

import javax.inject._
import play.api.mvc._
import services.FizzBuzzService

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject() extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def fizzbuzz(start: Int, end: Int) = Action.async { request =>
    val (s, e) = if ( start < end ) (start, end) else (end, start)

    FizzBuzzService.rangeToSentence(s, e).map(Ok(_))
  }

}
